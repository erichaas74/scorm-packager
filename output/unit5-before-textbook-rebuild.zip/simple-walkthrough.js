(() => {
  'use strict';
  const lesson = window.walkthroughLesson;
  const svg = document.getElementById('scene');
  const prompt = document.getElementById('prompt');
  const explanation = document.getElementById('explanation');
  const pauseButton = document.getElementById('pause');
  const replayButton = document.getElementById('replay');
  const choices = [...document.querySelectorAll('[data-choice]')];
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const colors = { blue: '#285f9f', teal: '#007f89', orange: '#b65b14', yellow: '#f2c526', dark: '#153456', pale: '#dcecf8', grey: '#7890a5' };
  let phase = 'watch';
  let elapsed = 0;
  let lastTime = null;
  let paused = false;
  let selected = null;
  let completionSent = false;
  const revealDuration = 4800;

  function escapeText(value) {
    return String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
  }

  function text(x, y, value, anchor = 'start', className = '') {
    return `<text x="${x}" y="${y}" text-anchor="${anchor}" class="${className}">${escapeText(value)}</text>`;
  }

  function line(x1, y1, x2, y2, color = colors.blue, width = 3, dashed = false) {
    return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${color}" stroke-width="${width}"${dashed ? ' stroke-dasharray="7 7"' : ''}/>`;
  }

  function arrow(x1, y1, x2, y2, color = colors.blue, width = 5) {
    const angle = Math.atan2(y2 - y1, x2 - x1);
    return line(x1, y1, x2, y2, color, width) + `<path d="M${x2 - 14 * Math.cos(angle - .5)},${y2 - 14 * Math.sin(angle - .5)} L${x2},${y2} L${x2 - 14 * Math.cos(angle + .5)},${y2 - 14 * Math.sin(angle + .5)}" fill="none" stroke="${color}" stroke-width="${width}" stroke-linecap="round"/>`;
  }

  function circle(x, y, radius, color = colors.teal, outline = '#fff') {
    return `<circle cx="${x}" cy="${y}" r="${radius}" fill="${color}" stroke="${outline}" stroke-width="2"/>`;
  }

  function rect(x, y, width, height, fill = '#fff', stroke = '#bdd2e2', radius = 10) {
    return `<rect x="${x}" y="${y}" width="${width}" height="${height}" rx="${radius}" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`;
  }

  function curve(points, color = colors.teal, width = 5) {
    return `<path d="${points.map((point, index) => `${index ? 'L' : 'M'}${point[0].toFixed(2)},${point[1].toFixed(2)}`).join(' ')}" fill="none" stroke="${color}" stroke-width="${width}" stroke-linecap="round" stroke-linejoin="round"/>`;
  }

  function sineWave(startX, endX, baseY, amplitude, wavelength, offset = 0, color = colors.teal) {
    const points = [];
    for (let position = startX; position <= endX; position += 3) points.push([position, baseY - amplitude * Math.sin((position - startX) * 2 * Math.PI / wavelength - offset)]);
    return curve(points, color);
  }

  function bracket(x1, x2, y, label) {
    return line(x1, y, x2, y, colors.dark, 2) + line(x1, y - 7, x1, y + 7, colors.dark, 2) + line(x2, y - 7, x2, y + 7, colors.dark, 2) + text((x1 + x2) / 2, y - 12, label, 'middle', 'small');
  }

  function waveScene(reveal, progress, time) {
    const variant = lesson.variant;
    let drawing = '';
    if (['longitudinal', 'compression'].includes(variant)) {
      drawing += arrow(240, 60, 570, 60, colors.teal) + text(400, 40, 'Wave energy', 'middle');
      for (let row = 0; row < 5; row++) {
        for (let column = 0; column < 39; column++) {
          const origin = 80 + column * 17;
          const displacement = 11 * Math.sin(column * .46 - time * 3);
          drawing += circle(origin + displacement, 155 + row * 25, row === 2 && column === 19 ? 10 : 5, row === 2 && column === 19 ? colors.orange : colors.teal);
        }
      }
      if (variant === 'compression') {
        if (reveal) {
          const band = 80 + ((Math.PI + time * 3) / .46 % (Math.PI * 2 / .46)) * 17;
          drawing += rect(band - 23, 133, 46, 145, 'none', colors.orange) + text(400, 335, 'Compression = crowded particles', 'middle');
        } else drawing += text(400, 335, 'Find the crowded region', 'middle');
      } else {
        drawing += line(403, 130, 403, 280, colors.orange, 2, true);
        if (reveal) drawing += arrow(345, 320, 460, 320, colors.orange) + arrow(460, 320, 345, 320, colors.orange) + text(400, 365, 'Back and forth around one position', 'middle');
      }
      return drawing;
    }
    if (variant === 'interference' || variant === 'boundary' || variant === 'pulse') {
      drawing += line(60, 235, 740, 235, colors.grey, 2, true);
      const points = [];
      for (let position = 60; position <= 740; position += 3) {
        let displacement;
        if (variant === 'interference') {
          const first = reveal ? 245 + 310 * progress : 245;
          const second = reveal ? 555 - 310 * progress : 555;
          displacement = 50 * Math.exp(-Math.pow((position - first) / 36, 2)) + 50 * Math.exp(-Math.pow((position - second) / 36, 2));
        } else if (variant === 'boundary') {
          const center = reveal ? 560 + 650 * progress : 560;
          displacement = 65 * (Math.exp(-Math.pow((position - center) / 42, 2)) - Math.exp(-Math.pow((position - (1440 - center)) / 42, 2)));
        } else {
          const center = reveal ? 150 + 540 * progress : 150;
          displacement = 65 * Math.exp(-Math.pow((position - center) / 40, 2));
        }
        points.push([position, 235 - displacement]);
      }
      drawing += curve(points);
      if (variant === 'boundary') drawing += rect(720, 125, 16, 210, '#a9c4d8') + text(690, 100, 'Fixed end', 'end') + (reveal ? text(400, 355, 'The returning pulse is inverted', 'middle') : arrow(390, 150, 510, 150));
      if (variant === 'interference') drawing += text(220, 85, '1 cm', 'middle') + text(580, 85, '1 cm', 'middle') + (reveal ? text(400, 355, 'At overlap: 1 + 1 = 2 cm', 'middle') : arrow(270, 115, 345, 115) + arrow(530, 115, 455, 115));
      if (variant === 'pulse') drawing += text(120, 100, 'One shake', 'middle') + (reveal ? text(400, 355, 'One traveling pulse', 'middle') : arrow(235, 130, 370, 130));
      return drawing;
    }
    if (variant === 'standing') {
      drawing += text(400, 40, reveal ? 'Fixed nodes; moving antinodes' : 'Equal waves, opposite directions', 'middle');
      if (!reveal) {
        drawing += sineWave(80, 720, 140, 30, 320, time * 2) + arrow(240, 80, 400, 80);
        drawing += sineWave(80, 720, 290, 30, 320, -time * 2, colors.blue) + arrow(560, 230, 400, 230);
      } else {
        drawing += sineWave(80, 720, 215, 65 * Math.cos(time * 3), 320);
        for (let index = 0; index <= 4; index++) drawing += circle(80 + index * 160, 215, 7, colors.orange);
        drawing += text(400, 355, 'Orange points stay still: nodes', 'middle');
      }
      return drawing;
    }
    if (variant === 'beats') {
      drawing += text(200, 40, '440 Hz', 'middle') + text(600, 40, '444 Hz', 'middle');
      drawing += sineWave(60, 355, 110, 30, 65, time * 3) + sineWave(445, 740, 110, 30, 64.4, time * 3);
      if (reveal) {
        const points = [];
        for (let position = 60; position <= 740; position += 2) points.push([position, 270 - 55 * Math.cos((position - 60) * Math.PI * 4 / 680) * Math.sin((position - 60) * .30)]);
        drawing += curve(points) + text(400, 375, '|444 − 440| = 4 beats/s', 'middle');
      } else drawing += text(400, 270, 'Listen for a changing loudness', 'middle');
      return drawing;
    }
    if (variant === 'frequency') {
      drawing += text(400, 36, 'Same rope · speed = 8 m/s', 'middle');
      drawing += text(65, 90, 'Before: 4 Hz') + sineWave(80, 720, 150, 35, 240, time * 2);
      drawing += text(65, 240, 'After: 8 Hz');
      if (reveal) drawing += sineWave(80, 720, 300, 35, 120, time * 4) + bracket(140, 380, 205, '2 m') + bracket(110, 230, 365, '1 m');
      else drawing += text(400, 310, '?', 'middle');
      return drawing;
    }
    if (variant === 'pitch') {
      drawing += text(80, 55, 'Before') + sineWave(80, 720, 135, 25, 180, time * 2);
      drawing += text(80, 235, 'After') + sineWave(80, 720, 310, reveal ? 65 : 40, 180, time * 2);
      if (reveal) drawing += text(580, 235, 'Same frequency', 'middle');
      return drawing;
    }
    const amplitude = 65;
    const wavelength = 240;
    const offset = ['amplitude', 'wavelength'].includes(variant) ? 0 : variant === 'period' ? time * 4 * Math.PI : time * 2.6;
    drawing += line(60, 230, 740, 230, colors.grey, 2, true) + sineWave(80, 720, 230, amplitude, wavelength, offset);
    if (variant === 'amplitude') {
      drawing += bracket(140, 380, 120, 'One full cycle') + line(140, 230, 140, 165, colors.orange, 3) + text(170, 205, '3 cm');
      drawing += text(540, 260, 'Equilibrium', 'middle');
      if (reveal) drawing += text(400, 355, 'Amplitude = 3 cm', 'middle');
    } else if (variant === 'wavelength') {
      drawing += circle(140, 165, 8, colors.orange) + circle(380, 165, 8, colors.orange);
      if (reveal) drawing += bracket(140, 380, 120, 'One wavelength');
      else drawing += text(400, 75, 'Compare matching points', 'middle');
    } else if (variant === 'period') {
      drawing += text(400, 60, 'Frequency = 2 Hz', 'middle');
      drawing += circle(440, 230 - amplitude * Math.sin((440 - 80) * 2 * Math.PI / wavelength - offset), 10, colors.orange);
      if (reveal) drawing += text(400, 355, 'T = 1 / 2 = 0.5 s', 'middle');
    } else {
      const particleX = 440;
      drawing += arrow(280, 70, 540, 70, colors.teal) + text(410, 45, 'Wave energy', 'middle');
      drawing += line(particleX, 140, particleX, 320, colors.orange, 2, true) + circle(particleX, 230 - amplitude * Math.sin((particleX - 80) * 2 * Math.PI / wavelength - offset), 11, colors.orange);
      if (reveal) drawing += text(400, 365, 'The particle stays at the same horizontal position', 'middle', 'small');
    }
    return drawing;
  }

  function opticsScene(reveal, progress) {
    let drawing = '';
    if (lesson.variant === 'lens') {
      const objectX = 95, lensX = 320, focal = 90, imageX = 470;
      drawing += line(30, 215, 760, 215, colors.grey, 2);
      drawing += `<path d="M320 70 Q365 215 320 355 Q275 215 320 70Z" fill="#c7e4f5" stroke="${colors.blue}" stroke-width="3"/>`;
      for (const [position, label] of [[140, '2F'], [230, 'F'], [410, 'F'], [500, '2F']]) drawing += circle(position, 215, 4, colors.blue) + text(position, 245, label, 'middle', 'small');
      drawing += arrow(objectX, 215, objectX, 125, colors.orange) + text(objectX, 95, 'Object', 'middle');
      if (reveal) {
        const length = Math.min(1, progress * 1.7);
        drawing += line(objectX, 125, lensX, 125, colors.orange) + line(lensX, 125, lensX + (imageX - lensX) * length, 125 + 150 * length, colors.orange);
        drawing += line(objectX, 125, imageX, 275, colors.teal);
        if (progress > .6) drawing += arrow(imageX, 215, imageX, 275, colors.blue) + text(565, 330, 'Real · inverted', 'middle');
      } else drawing += text(560, 100, 'Image?', 'middle');
      return drawing;
    }
    const isWater = lesson.variant === 'water';
    const panels = isWater ? [{ center: 400, n: 1.5, label: 'Shallow water · 2 m/s', top: 'Deep water · 3 m/s' }] : [{ center: 210, n: 1.52, label: 'Glass · n = 1.52', top: 'Air · n = 1.00' }, { center: 590, n: 2.42, label: 'Diamond · n = 2.42', top: 'Air · n = 1.00' }];
    drawing += rect(15, 195, 770, 190, '#cce7ea', '#accbd2') + line(15, 195, 785, 195, colors.blue, 3);
    for (const panel of panels) {
      const center = panel.center;
      drawing += line(center, 55, center, 345, colors.grey, 2, true) + text(center + 12, 85, 'Normal', 'start', 'small');
      drawing += text(center, 35, panel.top, 'middle', 'small') + text(center, 375, panel.label, 'middle', 'small');
      drawing += arrow(center - 90, 105, center, 195, colors.orange, 5);
      drawing += text(center - 50, 180, '45°', 'end', 'small');
      if (reveal) {
        const theta = Math.asin(Math.sin(Math.PI / 4) / panel.n);
        const length = 145 * Math.min(1, progress * 2);
        drawing += arrow(center, 195, center + length * Math.sin(theta), 195 + length * Math.cos(theta), colors.orange, 5);
        drawing += `<path d="M${center},245 A50 50 0 0 0 ${center + 50 * Math.sin(theta)},${195 + 50 * Math.cos(theta)}" fill="none" stroke="${colors.blue}" stroke-width="2"/>`;
        drawing += text(center + 45, 300, `${(theta * 180 / Math.PI).toFixed(0)}°`, 'start', 'small');
      }
    }
    return drawing;
  }

  function diffractionScene(reveal, progress, time) {
    let drawing = '';
    if (lesson.variant === 'double') {
      drawing += rect(265, 70, 14, 115, colors.blue) + rect(265, 205, 14, 35, colors.blue) + rect(265, 260, 14, 100, colors.blue);
      for (let index = 0; index < 5; index++) drawing += line(50 + index * 40 + time * 10 % 40, 90, 50 + index * 40 + time * 10 % 40, 345, colors.teal, 3);
      drawing += text(265, 40, 'Two slits', 'middle') + rect(690, 65, 40, 300, '#dce6ee');
      if (reveal) {
        for (const origin of [195, 250]) for (let radius = 45; radius < 370 * Math.max(.15, progress); radius += 45) drawing += `<path d="M${275},${origin - radius} A${radius} ${radius} 0 0 1 ${275},${origin + radius}" fill="none" stroke="${colors.teal}" opacity=".35" stroke-width="2"/>`;
        for (let index = 0; index < 11; index++) drawing += rect(692, 70 + index * 26, 36, 18, index % 2 ? '#153456' : '#f7d74b', 'none', 1);
        drawing += text(590, 390, 'Bright / dark', 'middle');
      }
      return drawing;
    }
    for (const [center, gap, label] of [[210, 42, 'Narrow gap'], [590, 130, 'Wide gap']]) {
      drawing += text(center, 40, label, 'middle');
      for (let index = 0; index < 3; index++) drawing += line(center - 140, 65 + index * 35, center + 140, 65 + index * 35, colors.teal, 3);
      drawing += line(center - 160, 180, center - gap / 2, 180, colors.blue, 10) + line(center + gap / 2, 180, center + 160, 180, colors.blue, 10);
      if (reveal) {
        for (let radius = 40; radius <= 170 * Math.max(.25, progress); radius += 40) {
          if (gap < 50) drawing += `<path d="M${center - radius},180 A${radius} ${radius} 0 0 0 ${center + radius},180" fill="none" stroke="${colors.teal}" stroke-width="3"/>`;
          else drawing += `<path d="M${center - gap / 2 - radius * .17},${180 + radius * .85} Q${center},${180 + radius * 1.12} ${center + gap / 2 + radius * .17},${180 + radius * .85}" fill="none" stroke="${colors.teal}" stroke-width="3"/>`;
        }
      }
    }
    return drawing;
  }

  function spectrumScene(reveal, progress, time) {
    let drawing = '';
    if (lesson.variant === 'doppler') {
      const bars = [150, 280, 390, 570];
      drawing += text(50, 45, 'Lab reference') + text(50, 215, 'Observed star');
      drawing += rect(60, 70, 680, 85, 'url(#spectrum)', 'none') + rect(60, 240, 680, 85, 'url(#spectrum)', 'none');
      for (const position of bars) {
        drawing += line(position, 72, position, 153, colors.dark, 7);
        drawing += line(position + (reveal ? 48 * progress : 48), 242, position + (reveal ? 48 * progress : 48), 323, colors.dark, 7);
      }
      drawing += arrow(190, 370, 610, 370, colors.orange, 3) + text(400, 355, 'Longer wavelength', 'middle');
      if (reveal) drawing += text(590, 210, 'Moving away', 'middle');
      return drawing;
    }
    drawing += text(210, 50, 'Red · 700 nm', 'middle') + text(590, 50, 'UV · 350 nm', 'middle');
    drawing += sineWave(55, 360, 150, 40, 150, time * 2, '#a83f38') + sineWave(440, 745, 150, 40, 75, time * 4, '#6e4b9c');
    drawing += text(210, 245, 'Longer wavelength', 'middle', 'small') + text(590, 245, 'Shorter wavelength', 'middle', 'small');
    if (reveal) drawing += text(210, 310, '1.77 eV', 'middle', 'value') + text(590, 310, '3.54 eV', 'middle', 'value') + text(400, 375, 'E = hf = hc / λ', 'middle');
    return drawing;
  }

  function communicationScene(reveal, progress, time) {
    const infrared = lesson.variant === 'infrared';
    let drawing = rect(80, 125, 100, 160, '#dcebf6') + text(130, 325, infrared ? 'Remote' : 'Phone', 'middle');
    drawing += infrared ? rect(570, 110, 170, 150, '#dcebf6') + rect(585, 125, 140, 120, '#c4d9e6') + text(655, 325, 'TV', 'middle') : `<path d="M580 240V190 A65 65 0 0 1 710 190V240" fill="none" stroke="${colors.blue}" stroke-width="15"/>` + rect(570, 215, 30, 65, colors.teal) + rect(690, 215, 30, 65, colors.teal) + text(650, 325, 'Headphones', 'middle');
    drawing += text(400, 65, infrared ? 'A coded signal' : 'Nearby devices', 'middle');
    if (reveal) {
      drawing += sineWave(210, 540, 210, 30, 90, time * 5, colors.orange);
      drawing += text(400, 370, infrared ? 'Infrared = electromagnetic waves' : 'Bluetooth = short-range radio', 'middle', 'small');
    }
    return drawing;
  }

  function raceScene(reveal, progress) {
    const electromagnetic = lesson.variant === 'em';
    const labels = electromagnetic ? ['Radio', 'Visible'] : ['Air', 'Steel'];
    let drawing = text(400, 40, electromagnetic ? 'Same distance · vacuum' : 'Same distance', 'middle');
    labels.forEach((label, index) => {
      const y = 140 + index * 140;
      drawing += text(30, y + 8, label) + rect(170, y - 35, 540, 70, index ? '#d4eaeb' : '#e4eff8');
      const fraction = !reveal ? 0 : Math.min(1, progress * (electromagnetic ? 1.25 : index ? 1.1 * 5900 / 343 : 1.1));
      drawing += circle(190 + 490 * fraction, y, 15, index ? colors.orange : colors.teal);
      drawing += line(680, y - 45, 680, y + 45, colors.blue, 3, true);
      if (reveal && fraction === 1) drawing += text(640, y - 55, 'Arrived', 'middle', 'small');
    });
    if (reveal) drawing += text(400, 380, electromagnetic ? 'Both: 3.00 × 10⁸ m/s' : 'Air ≈ 343 m/s · Steel ≈ 5,900 m/s', 'middle', 'small');
    return drawing;
  }

  function intensityScene(reveal, progress) {
    let drawing = circle(100, 210, 22, colors.orange) + text(100, 280, 'Source', 'middle');
    for (const radius of [120, 240, 360, 480]) drawing += `<path d="M${100 + radius * .5},${210 - radius * .45} Q${100 + radius * 1.2},210 ${100 + radius * .5},${210 + radius * .45}" fill="none" stroke="#8cb8c6" stroke-width="2"/>`;
    drawing += rect(300, 160, 70, 100, '#c4e7e9', colors.teal) + text(335, 135, '1 m', 'middle') + text(335, 300, '100%', 'middle');
    drawing += rect(570, 110, 140, 200, '#d8eaf4', colors.blue) + text(640, 85, '2 m', 'middle');
    drawing += text(640, 355, reveal ? '25%' : '?', 'middle', 'value');
    if (reveal) drawing += text(400, 390, 'I₂ / I₁ = (1 / 2)² = 1/4', 'middle');
    return drawing;
  }

  function nucleus(x, y, count = 24, scale = 1) {
    let drawing = '';
    for (let index = 0; index < count; index++) {
      const radius = Math.sqrt(index) * 8 * scale;
      const angle = index * 2.4;
      drawing += circle(x + radius * Math.cos(angle), y + radius * Math.sin(angle), 8 * scale, index % 2 ? colors.blue : colors.orange);
    }
    return drawing;
  }

  function nuclearScene(reveal, progress) {
    let drawing = '';
    if (lesson.variant === 'halflife') {
      drawing += text(400, 45, 'Start: 80 unstable nuclei', 'middle');
      for (let index = 0; index < 80; index++) {
        const decayed = reveal && ((index * 37) % 80) < Math.floor(progress * 40);
        drawing += circle(120 + index % 16 * 37, 105 + Math.floor(index / 16) * 42, 11, decayed ? '#8ca0b1' : colors.orange);
      }
      drawing += text(400, 355, reveal ? `${80 - Math.floor(progress * 40)} remain unstable` : 'After one half-life: ?', 'middle');
      if (reveal) drawing += text(400, 390, 'Illustrative sample; real counts vary', 'middle', 'small');
      return drawing;
    }
    if (lesson.variant === 'alpha') {
      drawing += nucleus(260, 210, reveal ? 28 : 32) + text(260, 70, reveal ? 'Radon-222' : 'Radium-226', 'middle') + text(260, 345, reveal ? '86 protons' : '88 protons', 'middle');
      if (reveal) {
        const distance = 90 + 290 * progress;
        drawing += nucleus(260 + distance, 210, 4) + text(610, 110, 'Alpha particle', 'middle') + text(610, 305, '2p + 2n', 'middle');
        drawing += text(400, 390, '226 − 4 = 222', 'middle');
      }
      return drawing;
    }
    drawing += text(400, 40, 'A neutron can trigger fission', 'middle');
    if (!reveal) drawing += circle(140, 210, 9, colors.teal) + arrow(170, 210, 260, 210) + nucleus(350, 210, 32) + nucleus(650, 105, 22) + nucleus(650, 310, 22);
    else {
      drawing += nucleus(310, 185, 14) + nucleus(360, 245, 14);
      for (const targetY of [105, 310]) {
        drawing += circle(380 + 270 * Math.min(1, progress * 1.5), 210 + (targetY - 210) * Math.min(1, progress * 1.5), 8, colors.teal);
        if (progress < .7) drawing += nucleus(650, targetY, 22);
        else drawing += nucleus(625, targetY - 20, 10) + nucleus(680, targetY + 20, 10) + arrow(675, targetY, 755, targetY, colors.teal);
      }
      drawing += text(400, 385, 'Released neutrons continue the chain', 'middle', 'small');
    }
    return drawing;
  }

  function oscillatorScene(reveal, progress, time) {
    const resonance = lesson.variant === 'resonance';
    const amplitude = resonance ? 25 + (reveal ? 95 * progress : 0) : 145;
    const position = 400 + amplitude * Math.sin(time * 3);
    let drawing = line(85, 270, 720, 270, colors.grey, 3) + line(400, 105, 400, 320, colors.grey, 2, true) + text(400, 360, 'Equilibrium', 'middle');
    const points = [[80, 220]];
    for (let index = 0; index < 30; index++) points.push([80 + (position - 115) * index / 29, 220 + (index % 2 ? 18 : -18)]);
    drawing += rect(60, 145, 20, 150, '#aac3d6') + curve(points, colors.blue, 3) + rect(position - 35, 185, 70, 70, '#b8dfe2', colors.teal);
    if (resonance) drawing += text(400, 60, reveal ? 'Matched rhythm → larger amplitude' : 'Small pushes at the natural frequency', 'middle', 'small');
    else {
      drawing += text(250, 75, 'Turning point', 'middle', 'small') + text(550, 75, 'Turning point', 'middle', 'small');
      if (reveal) {
        const velocity = Math.cos(time * 3) * 80;
        drawing += arrow(position, 150, position + velocity, 150, colors.orange) + text(400, 390, 'Fastest at equilibrium; zero speed at the ends', 'middle', 'small');
      }
    }
    return drawing;
  }

  function soundScene(reveal, progress, time) {
    let drawing = rect(55, 130, 85, 140, '#bed6e6') + text(100, 320, 'Speaker', 'middle') + circle(705, 190, 35, '#d8e7ef', colors.blue) + text(705, 320, 'Listener', 'middle');
    drawing += rect(175, 90, 450, 210, reveal ? '#f5f9fc' : '#d8ebf4');
    if (!reveal) {
      for (let index = 0; index < 70; index++) drawing += circle(195 + index % 14 * 30 + 4 * Math.sin(time * 4 + index), 120 + Math.floor(index / 14) * 35, 4, colors.teal);
      drawing += text(400, 55, 'Air carries vibrations', 'middle');
    } else {
      drawing += text(400, 200, 'Vacuum: no particles', 'middle') + text(400, 365, 'No sound crosses the gap', 'middle');
    }
    return drawing;
  }

  function harmonicsScene(reveal) {
    let drawing = rect(100, 120, 610, 160, '#d8ebf4', '#8bb3c5', 0) + line(100, 120, 100, 280, colors.blue, 12) + text(100, 80, 'Closed', 'middle') + text(710, 80, 'Open', 'middle');
    if (reveal) {
      const points = [];
      for (let position = 100; position <= 710; position += 3) points.push([position, 220 - 65 * Math.sin((position - 100) / 610 * Math.PI / 2)]);
      drawing += curve(points) + circle(100, 220, 7, colors.orange) + text(110, 330, 'Node', 'middle') + text(670, 330, 'Antinode', 'middle') + bracket(100, 710, 380, 'Pipe length = λ / 4');
    } else drawing += text(400, 215, 'First standing-wave mode?', 'middle');
    return drawing;
  }

  function photonsScene(reveal, progress, time) {
    let drawing = '';
    if (lesson.variant === 'brightness') {
      for (let lane = 0; lane < 2; lane++) {
        const y = 145 + lane * 150;
        drawing += text(40, y - 60, lane ? 'Brighter · same color' : 'Original light');
        drawing += rect(45, y - 30, 50, 60, '#b8d5e7') + rect(700, y - 45, 20, 90, '#b8d5e7');
        const count = reveal && lane ? 12 : 6;
        for (let index = 0; index < count; index++) drawing += circle(130 + ((index * 550 / count + time * 70) % 550), y, 8, colors.orange);
      }
      if (reveal) drawing += text(400, 385, 'More photons; same energy per photon', 'middle', 'small');
      return drawing;
    }
    const ionization = lesson.variant === 'ionization';
    const threshold = ionization ? '12 eV' : '2.3 eV';
    drawing += text(400, 40, `${ionization ? 'Ionization energy' : 'Work function'} = ${threshold}`, 'middle');
    for (let lane = 0; lane < 2; lane++) {
      const y = 150 + lane * 155;
      const energy = ionization ? lane ? '15 eV' : '5 eV' : lane ? '3.0 eV' : '1.5 eV';
      drawing += text(80, y - 42, `${energy} photon`);
      drawing += ionization ? circle(540, y, 32, '#dce9f4', colors.blue) + circle(540, y, 10, colors.orange) : rect(510, y - 45, 70, 90, '#a9c6d6');
      const photonX = reveal ? 180 + 350 * Math.min(1, progress * 2) : 180;
      if (!reveal || progress < .5) drawing += circle(photonX, y, 9, colors.orange);
      if (reveal && progress >= .5 && lane) drawing += circle(570 + 155 * (progress - .5) * 2, y - 25, 8, colors.blue) + arrow(590, y - 55, 710, y - 55, colors.blue, 3);
      else drawing += circle(570, y - 12, 7, colors.blue);
      if (reveal) drawing += text(660, y + 50, lane ? 'Electron freed' : 'No electron freed', 'middle', 'small');
    }
    return drawing;
  }

  function clocksScene(reveal, progress) {
    let drawing = '';
    for (const [center, label] of [[220, 'Earth clock'], [580, 'GPS clock']]) {
      drawing += circle(center, 185, 83, '#fff', '#8ba9bf') + text(center, 55, label, 'middle');
      drawing += line(center, 185, center, 120, colors.blue, 5) + line(center, 185, center + 45, 205, colors.blue, 4);
    }
    drawing += text(400, 325, reveal ? 'Uncorrected: about +38 μs/day' : 'Tiny timing error → what effect?', 'middle');
    if (reveal) drawing += text(400, 380, 'c × Δt ≈ 11 km of distance error', 'middle', 'small');
    return drawing;
  }

  const renderers = { wave: waveScene, optics: opticsScene, diffraction: diffractionScene, spectrum: spectrumScene, communication: communicationScene, race: raceScene, intensity: intensityScene, nuclear: nuclearScene, oscillator: oscillatorScene, sound: soundScene, harmonics: harmonicsScene, photons: photonsScene, clocks: clocksScene };

  function render() {
    const revealed = phase === 'reveal' || phase === 'complete';
    const progress = phase === 'complete' ? 1 : phase === 'reveal' ? Math.min(1, elapsed / revealDuration) : 0;
    let time = phase === 'watch' ? elapsed / 1000 : phase === 'predict' ? 2.4 : 2.4 + progress * 4;
    if (reducedMotion.matches) time = revealed ? 4 : 0;
    svg.innerHTML = `<defs><linearGradient id="spectrum"><stop stop-color="#7777bc"/><stop offset=".3" stop-color="#69a5d1"/><stop offset=".55" stop-color="#80b894"/><stop offset=".75" stop-color="#e6cc71"/><stop offset="1" stop-color="#c7736c"/></linearGradient><clipPath id="sceneClip"><rect width="800" height="410"/></clipPath></defs><g clip-path="url(#sceneClip)">${renderers[lesson.type](revealed, progress, time)}</g>`;
    svg.dataset.phase = phase;
  }

  function setPhase(next) {
    phase = next;
    elapsed = 0;
    choices.forEach(button => { button.hidden = phase !== 'predict'; button.disabled = phase !== 'predict'; });
    pauseButton.hidden = phase === 'predict' || phase === 'complete';
    if (phase === 'watch') {
      prompt.textContent = 'Watch the setup.';
      explanation.textContent = '';
      svg.setAttribute('aria-label', lesson.title + '. ' + lesson.question);
    } else if (phase === 'predict') {
      prompt.textContent = lesson.question;
      explanation.textContent = '';
    } else if (phase === 'reveal') {
      prompt.textContent = 'Watch what happens.';
      explanation.textContent = '';
    } else {
      prompt.textContent = selected === lesson.correct ? 'Correct.' : 'Here is what happens.';
      explanation.textContent = lesson.explanation;
      svg.setAttribute('aria-label', lesson.explanation);
      if (!completionSent) {
        completionSent = true;
        window.parent.postMessage({ type: 'complete' }, '*');
      }
    }
    render();
  }

  function choose(index) {
    if (phase !== 'predict') return;
    selected = index;
    paused = false;
    pauseButton.textContent = 'Pause';
    setPhase(reducedMotion.matches ? 'complete' : 'reveal');
    replayButton.focus({ preventScroll: true });
  }

  function restart() {
    paused = false;
    selected = null;
    lastTime = null;
    pauseButton.textContent = 'Pause';
    setPhase(reducedMotion.matches ? 'predict' : 'watch');
  }

  function frame(timestamp) {
    const delta = lastTime === null ? 0 : Math.min(100, timestamp - lastTime);
    lastTime = timestamp;
    if (!paused && (phase === 'watch' || phase === 'reveal')) {
      elapsed += delta;
      if (phase === 'watch' && elapsed >= 2400) setPhase('predict');
      else if (phase === 'reveal' && elapsed >= revealDuration) setPhase('complete');
      else render();
    }
    requestAnimationFrame(frame);
  }

  choices.forEach(button => button.addEventListener('click', () => choose(Number(button.dataset.choice))));
  pauseButton.addEventListener('click', () => { paused = !paused; pauseButton.textContent = paused ? 'Play' : 'Pause'; });
  replayButton.addEventListener('click', restart);
  restart();
  requestAnimationFrame(frame);
})();
