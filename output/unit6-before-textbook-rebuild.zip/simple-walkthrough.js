(() => {
  'use strict';
  const lesson = window.walkthroughLesson;
  const svg = document.getElementById('scene');
  const prompt = document.getElementById('prompt');
  const explanation = document.getElementById('explanation');
  const pauseButton = document.getElementById('pause');
  const replayButton = document.getElementById('replay');
  const choices = [...document.querySelectorAll('[data-choice]')];
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const colors = { blue: '#285f9f', teal: '#007f89', orange: '#b65b14', yellow: '#f2c526', dark: '#153456', pale: '#dcecf8', grey: '#7890a5' };
  let phase = 'watch';
  let elapsed = 0;
  let lastTime = null;
  let paused = false;
  let selected = null;
  let completionSent = false;
  const revealDuration = 4800;

  function escapeText(value) {
    return String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
  }

  function text(x, y, value, anchor = 'start', className = '') {
    return `<text x="${x}" y="${y}" text-anchor="${anchor}" class="${className}">${escapeText(value)}</text>`;
  }

  function line(x1, y1, x2, y2, color = colors.blue, width = 3, dashed = false) {
    return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${color}" stroke-width="${width}"${dashed ? ' stroke-dasharray="7 7"' : ''}/>`;
  }

  function arrow(x1, y1, x2, y2, color = colors.blue, width = 5) {
    const angle = Math.atan2(y2 - y1, x2 - x1);
    return line(x1, y1, x2, y2, color, width) + `<path d="M${x2 - 14 * Math.cos(angle - .5)},${y2 - 14 * Math.sin(angle - .5)} L${x2},${y2} L${x2 - 14 * Math.cos(angle + .5)},${y2 - 14 * Math.sin(angle + .5)}" fill="none" stroke="${color}" stroke-width="${width}" stroke-linecap="round"/>`;
  }

  function circle(x, y, radius, color = colors.teal, outline = '#fff') {
    return `<circle cx="${x}" cy="${y}" r="${radius}" fill="${color}" stroke="${outline}" stroke-width="2"/>`;
  }

  function rect(x, y, width, height, fill = '#fff', stroke = '#bdd2e2', radius = 10) {
    return `<rect x="${x}" y="${y}" width="${width}" height="${height}" rx="${radius}" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`;
  }

  function curve(points, color = colors.teal, width = 5) {
    return `<path d="${points.map((point, index) => `${index ? 'L' : 'M'}${point[0].toFixed(2)},${point[1].toFixed(2)}`).join(' ')}" fill="none" stroke="${color}" stroke-width="${width}" stroke-linecap="round" stroke-linejoin="round"/>`;
  }

  function sineWave(startX, endX, baseY, amplitude, wavelength, offset = 0, color = colors.teal) {
    const points = [];
    for (let position = startX; position <= endX; position += 3) points.push([position, baseY - amplitude * Math.sin((position - startX) * 2 * Math.PI / wavelength - offset)]);
    return curve(points, color);
  }

  function bracket(x1, x2, y, label) {
    return line(x1, y, x2, y, colors.dark, 2) + line(x1, y - 7, x1, y + 7, colors.dark, 2) + line(x2, y - 7, x2, y + 7, colors.dark, 2) + text((x1 + x2) / 2, y - 12, label, 'middle', 'small');
  }


  const renderers = window.unit6Scenes({ lesson, colors, text, line, arrow, circle, rect, curve, bracket });

  function render() {
    const revealed = phase === 'reveal' || phase === 'complete';
    const progress = phase === 'complete' ? 1 : phase === 'reveal' ? Math.min(1, elapsed / revealDuration) : 0;
    let time = phase === 'watch' ? elapsed / 1000 : phase === 'predict' ? 2.4 : 2.4 + progress * 4;
    if (reducedMotion.matches) time = revealed ? 4 : 0;
    svg.innerHTML = `<defs><linearGradient id="spectrum"><stop stop-color="#7777bc"/><stop offset=".3" stop-color="#69a5d1"/><stop offset=".55" stop-color="#80b894"/><stop offset=".75" stop-color="#e6cc71"/><stop offset="1" stop-color="#c7736c"/></linearGradient><clipPath id="sceneClip"><rect width="800" height="410"/></clipPath></defs><g clip-path="url(#sceneClip)">${renderers[lesson.type](revealed, progress, time)}</g>`;
    svg.dataset.phase = phase;
  }

  function setPhase(next) {
    phase = next;
    elapsed = 0;
    choices.forEach(button => { button.hidden = phase !== 'predict'; button.disabled = phase !== 'predict'; });
    pauseButton.hidden = phase === 'predict' || phase === 'complete';
    if (phase === 'watch') {
      prompt.textContent = 'Watch the setup.';
      explanation.textContent = '';
      svg.setAttribute('aria-label', lesson.title + '. ' + lesson.question);
    } else if (phase === 'predict') {
      prompt.textContent = lesson.question;
      explanation.textContent = '';
    } else if (phase === 'reveal') {
      prompt.textContent = 'Watch what happens.';
      explanation.textContent = '';
    } else {
      prompt.textContent = selected === lesson.correct ? 'Correct.' : 'Here is what happens.';
      explanation.textContent = lesson.explanation;
      svg.setAttribute('aria-label', lesson.explanation);
      if (!completionSent) {
        completionSent = true;
        window.parent.postMessage({ type: 'complete' }, '*');
      }
    }
    render();
  }

  function choose(index) {
    if (phase !== 'predict') return;
    selected = index;
    paused = false;
    pauseButton.textContent = 'Pause';
    setPhase(reducedMotion.matches ? 'complete' : 'reveal');
    replayButton.focus({ preventScroll: true });
  }

  function restart() {
    paused = false;
    selected = null;
    lastTime = null;
    pauseButton.textContent = 'Pause';
    setPhase(reducedMotion.matches ? 'predict' : 'watch');
  }

  function frame(timestamp) {
    const delta = lastTime === null ? 0 : Math.min(100, timestamp - lastTime);
    lastTime = timestamp;
    if (!paused && (phase === 'watch' || phase === 'reveal')) {
      elapsed += delta;
      if (phase === 'watch' && elapsed >= 2400) setPhase('predict');
      else if (phase === 'reveal' && elapsed >= revealDuration) setPhase('complete');
      else render();
    }
    requestAnimationFrame(frame);
  }

  choices.forEach(button => button.addEventListener('click', () => choose(Number(button.dataset.choice))));
  pauseButton.addEventListener('click', () => { paused = !paused; pauseButton.textContent = paused ? 'Play' : 'Pause'; });
  replayButton.addEventListener('click', restart);
  restart();
  requestAnimationFrame(frame);
})();

